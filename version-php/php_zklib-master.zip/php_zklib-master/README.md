### *** Note: Abandoned library  ***

# PHP ZKLib #

PHP library to interacts with ZK Time and Attendance Devices.

Library for connecting under the network using the UDP protocol and port 4370 

See ZK communication protocol manual [here](zklib/docs/ZK_Communication_protocol_manual_CMD.pdf)
